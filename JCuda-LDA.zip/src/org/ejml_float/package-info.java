/**
 * The modules in org.ejml_float are modified from 'ejml-0.29.jar'. 
 * These codes are primarily for storing single precison matrices with float[] arrays.
 */
/**
 * @author Lin Chi-Min (v381654729@gmail.com)
 *
 */
package org.ejml_float;